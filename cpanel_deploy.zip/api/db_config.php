<?php
// =============================================================
// CONFIGURAÇÕES DO BANCO DE DADOS - EDITE ANTES DE SUBIR
// =============================================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'seu_banco');       // Nome do banco criado no cPanel
define('DB_USER', 'seu_usuario');     // Usuário do banco no cPanel
define('DB_PASS', 'sua_senha');       // Senha do banco no cPanel
define('DB_CHARSET', 'utf8mb4');
