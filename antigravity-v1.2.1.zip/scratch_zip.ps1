# Limpar arquivos ZIP antigos
Remove-Item -Path antigravity-v*.zip, simulador-dist-v*.zip -Force -ErrorAction SilentlyContinue

# Criar simulador-dist-v1.2.1.zip
Compress-Archive -Path dist\*, CHANGELOG.md -DestinationPath simulador-dist-v1.2.1.zip -Force

# Criar antigravity-v1.2.1.zip
$exclude = @("node_modules", "dist", ".git", ".gemini", "*.zip")
$filesToZip = Get-ChildItem -Path . -Exclude $exclude
Compress-Archive -Path $filesToZip -DestinationPath antigravity-v1.2.1.zip -Force

Write-Host "Zips criados com sucesso!"
