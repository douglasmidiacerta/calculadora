# CHANGELOG - Simulador de Vendas e Taxas (Calculadora)

Todas as alterações notáveis neste projeto serão documentadas neste arquivo.

## [1.2.2] - 2026-05-20

### Adicionado
- **Favicon de Marca Personalizável**:
  - Inserida tag de referência de ícone `<link rel="icon" type="image/png" href="favicon.png" />` no `<head>` do `index.html` raiz. Isso permite que você coloque uma imagem customizada de ícone em cada pasta correspondente no cPanel, e o navegador a renderize automaticamente como favicon específico.
- **Título de Aba Dinâmico por Parceiro**:
  - Implementado carregamento dinâmico do título da aba do navegador utilizando `useEffect` e `document.title` diretamente no ciclo de vida do componente do React em `src/App.tsx`. O título agora muda de forma limpa e imediata para `<Nome do Parceiro> - Calculadora` (ex: "D Cred - Calculadora" ou "CredPara - Calculadora").
- **Replicação SaaS & Compilação Completa**:
  - Re-executado o script de sincronização PowerShell e compilado novamente os bundles estáticos de produção na raiz e em todas as pastas SaaS (`d_cred/`, `credpara/`, `melhor_credi/`), mantendo a homogeneidade absoluta do ecossistema.

## [1.2.1] - 2026-05-20

### Adicionado
- **Configuração de Lucro Líquido do Dono**:
  - Adicionada opção dedicada nas Opções de Exibição do Simulador (Aba 1) para o Dono ativar/desativar a exibição da coluna de Lucro Líquido em seu próprio simulador (sincronizada via JSON remoto no servidor pela flag `show_lucro_dono` / `showLucroDono`).
- **Restrição de Acesso a Taxas e Custos de Máquina**:
  - Bloqueada a edição dos inputs decimais da **Aba 2 (Fatores Base)** e da **Aba 3 (Custo de Máquina)** no Painel Administrativo para o Dono, apresentando-os estritamente como visualização/somente-leitura. Os inputs agora contam com desabilitação nativa (`disabled`) e estilização suave e harmônica em tom cinza desativado para indicação visual clara de visualização-técnica.
- **Replicação SaaS Automática**:
  - Sincronização e compilação do código base em todas as instâncias de parceiros (`saas/d_cred/`, `saas/credpara/`, `saas/melhor_credi/`), garantindo que todos contem com o painel admin 100% atualizado e seus respectivos bundles de produção otimizados.

## [1.2.0] - 2026-05-20

### Adicionado
- **Arquitetura Multi-Tenant SaaS em Subpastas**:
  - Criação e isolamento do projeto para múltiplos parceiros em pastas individuais sob `saas/` (`saas/d_cred/`, `saas/credpara/`, `saas/melhor_credi/`).
  - Script PowerShell de replicação limpa de atualizações (`scratch/copy_to_partners.ps1`) para copiar de forma inteligente os arquivos da raiz (base) para todas as subpastas ignorando bundles e caches.
- **Gestão de Níveis de Acesso e Roles**:
  - Definição do perfil **Dono da Empresa (`dono`)** com acesso administrativo completo automático e ao painel de configurações.
  - Definição do perfil **Vendedor Comum (`vendedor`)** com visualização restrita, ocultação do botão "Admin" e controle dinâmico da coluna de "Lucro Líquido" (comissão) na tabela.
- **Persistência de Taxas Sincronizada no Servidor**:
  - Endpoint da API em PHP (`public/api/config/index.php`) e Express local (`server.ts` sob `/api/config`) para persistir configurações e taxas ativas no servidor no arquivo dinâmico `api/config/config.json`.
  - As configurações são lidas no carregamento da aplicação logo após a autenticação, sincronizando as alterações salvas pelo Dono para todos os vendedores instantaneamente.
- **Switch Administrativo de Liberação de Comissão**:
  - Substituição do antigo switch de ocultar/mostrar do admin por um controle de maior granularidade: **"Liberar Tabela de Comissão para os Vendedores"**, que bloqueia ou libera o lucro/comissão no simulador para o perfil vendedor de forma remota no servidor.
- **Personalização de Marcas para Parceiros**:
  - Customização de marcas individuais no rodapé de copyright e no PNG gerado de exportação para cada parceiro ("D Cred", "CredPara" e "Melhor Credi").

## [1.1.2] - 2026-05-19

### Alterado
- **Ajuste Fino do Destino de Deploy FTP**:
  - Ajustada a propriedade `server-dir` no arquivo `.github/workflows/deploy.yml` de `/public_html/calculadora/` para `./`.
  - Esta alteração permite compatibilidade total com contas FTP dedicadas criadas no cPanel que já estejam restritas ao diretório `/public_html/calculadora`, evitando problemas de permissão e estruturação incorreta de diretórios durante a sincronização automática.

## [1.1.1] - 2026-05-19

### Adicionado
- **Pipeline de Integração e Deploy Contínuo (CI/CD) via GitHub Actions**:
  - Criação do arquivo de workflow `.github/workflows/deploy.yml` pré-configurado.
  - Implementação de build automático no ambiente do GitHub (`npm ci && npm run build`) e sincronização dos ativos otimizados da pasta `/dist` diretamente para o servidor cPanel via FTP utilizando a action `SamKirkland/FTP-Deploy-Action`. Isso elimina a necessidade de chaves SSH ou de clicar manualmente no botão do cPanel para efetuar os próximos deploys.

## [1.1.0] - 2026-05-19

### Adicionado
- **Integração de Deploy Automatizado com cPanel (`.cpanel.yml`)**:
  - Criação do arquivo de configuração `.cpanel.yml` na raiz do projeto. Ele instrui a engine de deploy do Git do cPanel a usar o `rsync` para sincronizar os arquivos compilados da pasta `dist/` diretamente na pasta de destino de publicação pública (ex: `/public_html/calculadora`), ignorando os arquivos de código-fonte e o histórico do Git no deploy final.

## [1.0.9] - 2026-05-19

### Adicionado
- **Zebra Striping (Linhas Intercaladas) nas Tabelas**:
  - Implementação de coloração intercalada para as linhas de parcelas da tabela de simulação na tela comum (`bg-white` e `bg-emerald-50/30`).
  - Adicionado suporte a coloração intercalada também na **geração de imagem compactada vertical**, alternando entre branco (`#ffffff`) e um verde bem suave (`#eaf7ed`).
  - Esta alteração melhora significativamente a legibilidade da tabela ao comparar parcelas, taxas e valores totais a passar ou receber tanto no computador/celular quanto nas imagens geradas e compartilhadas.

## [1.0.8] - 2026-05-19

### Alterado
- **Remoção Definitiva dos Botões de Customização Visual no Cabeçalho**:
  - Os botões "Ver Taxa Custo/Cliente" e "Ocultar/Mostrar Lucro" foram removidos por completo do header do simulador principal.
  - Isso garante uma interface 100% limpa, segura e profissional para vendedores e clientes finais, sem indícios visuais de margem ou custos de máquina para usuários comuns.
  - Todo o controle de visibilidade (exibição de lucro líquido e tipo de taxa exibida) foi centralizado exclusivamente na **Aba 1 (Opções & Acréscimos)** do Painel Administrativo restrito (protegido pela senha **`3x51ELCO`**), mantendo a persistência integrada via `localStorage`.

## [1.0.7] - 2026-05-19

### Adicionado
- **Área Administrativa Protegida por Senha**:
  - Implementação de um botão de engrenagem discreto no cabeçalho do simulador que atua como atalho para o painel administrativo.
  - Bloqueio por senha exigindo a digitação exata de **`3x51ELCO`** para autenticação da sessão administrativa.
- **Painel Administrativo com Abas Responsivas**:
  - **Aba 1 (Geral & Acréscimos)**:
    - Controle de visibilidade para ocultar/mostrar os botões de customização ("Ocultar Lucro" e "Ver Taxa Custo") para usuários/vendedores comuns.
    - Edição dos acréscimos por nível (Tabelas 1 a 5) das tabelas Normal e Promo.
    - Edição do campo **Acréscimo Geral** (+1%, +0.15%, etc.) somado dinamicamente no cálculo de todos os fatores das tabelas Normal e Promo.
  - **Aba 2 (Fatores Base)**: Edição direta das taxas mensais em formato multiplicador decimal de 1x a 21x para as tabelas Normal e Promo.
  - **Aba 3 (Custo de Máquina)**: Edição das taxas de desconto real cobradas pela adquirente de 1x a 21x para as bandeiras Master/Visa e Elo.
- **Mecanismo de Persistência e Backup**:
  - Salvamento instantâneo de todas as taxas customizadas no `localStorage` do navegador para manter as alterações ativas após o recarregamento da página (F5).
  - Botão **Restaurar Padrões** no painel administrativo para limpar as configurações locais e restaurar imediatamente as taxas estáticas originais de fábrica do código.
- **Dropdowns e Cálculos Dinâmicos**:
  - Reescrita do cálculo da simulação (`simulacao`) para processar os fatores e acréscimos dinâmicos.
  - Atualização automática dos dropdowns do simulador para refletir as taxas de acréscimo customizadas do admin em tempo real.


## [1.0.6] - 2026-05-19

### Adicionado
- **Botão para Mostrar/Ocultar Lucro Líquido na Tela**:
  - Adicionado estado `showLucro` (booleano) e botão moderno de alternância (Toggle com ícone dinâmico `Eye` / `EyeOff` do lucide-react) no cabeçalho do simulador. Isso permite ocultar a coluna "Lucro Líquido" na tela do computador/celular caso o cliente final esteja visualizando a tabela de simulação.
- **Botão para Trocar Taxas (Exibição de Taxa Cliente vs Taxa Máquina/Custo)**:
  - Adicionado estado `tipoTaxaExibida` (variando entre `"cliente"` e `"custo"`) e botão estilizado no cabeçalho. Permite alternar dinamicamente a exibição na tabela entre a **Taxa do Cliente** (taxa final calculada com acréscimo) e a **Taxa de Custo da Máquina** (taxa retida pela adquirente), com diferenciação de cores (verde para cliente e laranja/âmbar para máquina).

## [1.0.5] - 2026-05-19

### Adicionado
- **Resolução do Erro de Método Não Permitido (HTTP 405 / POST convertendo para GET)**:
  - Alterada a chamada do fetch de login no frontend (`src/App.tsx`) para usar a barra final (`api/login/`). Isso impede que o Apache redirecione a requisição POST para a URL com barra final gerando um redirecionamento HTTP 301, o qual converte o método para GET no navegador e descarta os parâmetros JSON (o que causava o erro HTTP 405 no script PHP).
  - Atualizada a rota correspondente no backend Express local (`server.ts`) para suportar em array tanto `/api/login` quanto `/api/login/`, assegurando o perfeito funcionamento da aplicação tanto localmente quanto em produção.

## [1.0.4] - 2026-05-19

### Adicionado
- **Redirecionamento Automático de Barra Final (Resolução Definitiva de Tela Branca em Subpasta)**:
  - Adicionado script Javascript inline no `<head>` do `index.html` que detecta se a aplicação foi aberta em uma subpasta sem a barra `/` final (ex: `dominio.com/calculadora`) e a redireciona dinamicamente adicionando a barra (ex: `dominio.com/calculadora/`). Isso assegura a correta resolução dos caminhos relativos dos assets (`./assets/...`) pelo navegador.
  - Adicionado tratamento de URL no servidor Apache via regras de rewrite no `public/.htaccess`, forçando o redirecionamento com barra final (HTTP 301) em diretórios físicos do servidor.

## [1.0.3] - 2026-05-19

### Adicionado
- **Suporte Total a Subpastas (Correção de Tela Branca)**: Configuração de `base: './'` no Vite 6 (`vite.config.ts`), garantindo a geração de caminhos de arquivos estáticos (assets JS/CSS) relativos em vez de absolutos.
- **Chamada de API Adaptável**: Alteração do endpoint do fetch do login de `/api/login` (absoluto) para `api/login` (relativo) no frontend React, viabilizando requisições corretas a partir de qualquer subpasta do servidor Apache no cPanel.
- **Otimização do .htaccess**: Ajustes preventivos para desativar a listagem de arquivos (`Options -Indexes`) sem interferir no mapeamento dinâmico de diretórios do Apache em subpastas.

## [1.0.2] - 2026-05-19

### Adicionado
- **Arquitetura Híbrida de Deploy**: Suporte a servidores sem Node.js instalando suporte nativo a PHP/Apache na rota `/api/login`.
- Mapeamento de diretório público `public/api/login/index.php` contendo a lógica de login em PHP compatível com qualquer cPanel compartilhado simples.
- Inicialização autônoma de tabelas MySQL do cPanel diretamente pelo arquivo PHP (`PDO`).
- Inclusão do arquivo `.htaccess` para roteamento amigável e proteção de rotas estáticas do Apache.
- Geração automática do build empacotado que acopla o frontend estático e o backend PHP diretamente na pasta `/dist`.

## [1.0.1] - 2026-05-19

### Adicionado
- Integração e suporte nativo ao banco de dados **MySQL** do cPanel utilizando a biblioteca `mysql2/promise`.
- Criação e inicialização automática da tabela de `usuarios` no banco de dados com a inserção do usuário `admin` padrão (`123456`).
- Sistema de autenticação adaptável na rota `/api/login` (tentativa no banco com fallback para credenciais estáticas de desenvolvimento).
- Configuração de escuta de porta dinâmica baseada em `process.env.PORT` para garantir a compatibilidade com o servidor Phusion Passenger do cPanel.
- Carregamento de variáveis de ambiente do arquivo `.env` via `dotenv/config`.
- Arquivo `.env.example` e `.env` atualizados com as configurações de conexão fornecidas pelo usuário.

## [1.0.0] - 2026-05-19

### Adicionado
- Estruturação do repositório inicial importado do AI Studio.
- Integração da pasta de gestão de inteligência e contexto `/ai_context`.
- Configuração do histórico mestre do projeto (`ai_context/historico_mestre.md`) e controle de checkpoints de desenvolvimento (`ai_context/sessao_atual.md`).
- Instalação e auditoria de 216 pacotes NPM requeridos pelo stack de tecnologias.
- Suporte para exportação de imagem em formato vertical móvel compactado (480px).
- Script de compilação integrado no Vite 6 + esbuild, gerando o bundle do frontend em `dist` e o servidor Express de produção em `dist/server.cjs`.
- Script de inicialização automatizado para execução no ambiente de produção (`npm start`).
