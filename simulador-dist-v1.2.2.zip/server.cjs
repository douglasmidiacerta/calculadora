var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_promise = __toESM(require("mysql2/promise"), 1);
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config();
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = process.env.PORT || 3e3;
  app.use(import_express.default.json());
  const pool = import_promise.default.createPool({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });
  try {
    const connection = await pool.getConnection();
    console.log("Database connected successfully!");
    await connection.query(`
      CREATE TABLE IF NOT EXISTS usuarios (
        id INT AUTO_INCREMENT PRIMARY KEY,
        usuario VARCHAR(50) NOT NULL UNIQUE,
        senha VARCHAR(255) NOT NULL,
        role VARCHAR(20) NOT NULL DEFAULT 'vendedor'
      )
    `);
    try {
      await connection.query("ALTER TABLE usuarios ADD COLUMN role VARCHAR(20) NOT NULL DEFAULT 'vendedor'");
    } catch (e) {
    }
    const [donoRows] = await connection.query("SELECT * FROM usuarios WHERE usuario = ?", ["dono"]);
    if (donoRows.length === 0) {
      await connection.query("INSERT INTO usuarios (usuario, senha, role) VALUES (?, ?, ?)", ["dono", "123456", "dono"]);
      console.log("Default dono user created in DB.");
    }
    const [vendedorRows] = await connection.query("SELECT * FROM usuarios WHERE usuario = ?", ["vendedor"]);
    if (vendedorRows.length === 0) {
      await connection.query("INSERT INTO usuarios (usuario, senha, role) VALUES (?, ?, ?)", ["vendedor", "123456", "vendedor"]);
      console.log("Default vendedor user created in DB.");
    }
    const [adminRows] = await connection.query("SELECT * FROM usuarios WHERE usuario = ?", ["admin"]);
    if (adminRows.length === 0) {
      await connection.query("INSERT INTO usuarios (usuario, senha, role) VALUES (?, ?, ?)", ["admin", "123456", "dono"]);
      console.log("Default admin user created in DB.");
    }
    connection.release();
  } catch (error) {
    console.error("Warning: Error initializing database (running in offline/fallback mode):", error);
  }
  const fs = require("fs");
  const configPath = import_path.default.join(process.cwd(), "config.json");
  app.get(["/api/config", "/api/config/"], (req, res) => {
    if (fs.existsSync(configPath)) {
      try {
        const content = fs.readFileSync(configPath, "utf-8");
        return res.json(JSON.parse(content));
      } catch (e) {
        return res.json({});
      }
    }
    return res.json({});
  });
  app.post(["/api/config", "/api/config/"], (req, res) => {
    try {
      fs.writeFileSync(configPath, JSON.stringify(req.body, null, 2), "utf-8");
      return res.json({ success: true, message: "Configura\xE7\xF5es salvas com sucesso no servidor local" });
    } catch (e) {
      return res.status(500).json({ success: false, message: "Falha ao salvar configura\xE7\xF5es localmente" });
    }
  });
  app.post(["/api/login", "/api/login/"], async (req, res) => {
    const { username, password } = req.body;
    try {
      const [rows] = await pool.query(
        "SELECT * FROM usuarios WHERE usuario = ? AND senha = ?",
        [username, password]
      );
      if (rows.length > 0) {
        return res.json({
          success: true,
          token: "mock-jwt-token",
          role: rows[0].role || "vendedor"
        });
      }
      if (username === "dono" && password === "123456") {
        return res.json({ success: true, token: "mock-jwt-token", role: "dono" });
      }
      if (username === "vendedor" && password === "123456") {
        return res.json({ success: true, token: "mock-jwt-token", role: "vendedor" });
      }
      if (username === "admin" && password === "123456") {
        return res.json({ success: true, token: "mock-jwt-token", role: "dono" });
      }
      return res.status(401).json({ success: false, message: "Usu\xE1rio ou senha inv\xE1lidos" });
    } catch (err) {
      console.error("Login DB error:", err);
      if (username === "dono" && password === "123456") {
        return res.json({ success: true, token: "mock-jwt-token", role: "dono" });
      }
      if (username === "vendedor" && password === "123456") {
        return res.json({ success: true, token: "mock-jwt-token", role: "vendedor" });
      }
      if (username === "admin" && password === "123456") {
        return res.json({ success: true, token: "mock-jwt-token", role: "dono" });
      }
      return res.status(500).json({ success: false, message: "Erro de conex\xE3o com o banco de dados" });
    }
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(Number(PORT), "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
